CREATE TABLE customers (
  id SERIAL PRIMARY KEY,
  name TEXT,
  email TEXT,
  status TEXT DEFAULT 'active'
);

CREATE TABLE feedback (
  id SERIAL PRIMARY KEY,
  customer_id INTEGER,
  rating INTEGER,
  comment TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE churn_risk (
  customer_id INTEGER PRIMARY KEY,
  score INTEGER,
  level TEXT,
  updated_at TIMESTAMP DEFAULT NOW()
);
