import { db } from "../config/db.js";
import { calculateRisk } from "../utils/riskRules.js";

export async function saveFeedback(customerId, rating, comment) {
  await db.query(
    "INSERT INTO feedback (customer_id, rating, comment) VALUES ($1,$2,$3)",
    [customerId, rating, comment]
  );

  await calculateRisk(customerId);
}
