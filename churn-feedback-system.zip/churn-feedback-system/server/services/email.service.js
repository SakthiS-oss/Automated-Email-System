import sgMail from "../config/email.js";
import { db } from "../config/db.js";

export async function sendMonthlyEmails() {
  const { rows } = await db.query("SELECT * FROM customers WHERE status='active'");

  for (let c of rows) {
    await sgMail.send({
      to: c.email,
      from: "support@yourcompany.com",
      subject: "Quick Check-In",
      html: `<a href="http://localhost:3000/feedback/${c.id}">Give Feedback</a>`
    });
  }
}
