import { db } from "../config/db.js";

export async function calculateRisk(customerId) {
  let score = 0;

  const { rows } = await db.query(
    "SELECT rating, comment FROM feedback WHERE customer_id=$1 ORDER BY created_at DESC LIMIT 3",
    [customerId]
  );

  rows.forEach(f => {
    if (f.rating <= 2) score += 40;
    if (f.rating === 3) score += 20;
    if (/(confused|frustrated|quit|stop)/i.test(f.comment)) score += 10;
  });

  let level = score >= 60 ? "high" : score >= 30 ? "medium" : "low";

  await db.query(
    `
    INSERT INTO churn_risk (customer_id, score, level)
    VALUES ($1,$2,$3)
    ON CONFLICT (customer_id)
    DO UPDATE SET score=$2, level=$3, updated_at=NOW()
    `,
    [customerId, score, level]
  );
}
