import cron from "node-cron";
import { sendMonthlyEmails } from "../services/email.service.js";

cron.schedule("0 9 1 * *", sendMonthlyEmails);
