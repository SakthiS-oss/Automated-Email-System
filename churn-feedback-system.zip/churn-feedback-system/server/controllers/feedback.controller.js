import { saveFeedback } from "../services/churn.service.js";

export async function submitFeedback(req, res) {
  const { customer_id, rating, comment } = req.body;
  await saveFeedback(customer_id, rating, comment);
  res.json({ success: true });
}
