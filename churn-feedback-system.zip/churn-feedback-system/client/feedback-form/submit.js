document.getElementById("form").onsubmit = async e => {
  e.preventDefault();

  await fetch("/api/feedback", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      customer_id: 1,
      rating: rating.value,
      comment: comment.value
    })
  });

  alert("Thanks!");
};
